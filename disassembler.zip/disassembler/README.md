# Binary Disassembler

Tested using insertion_sort.legv8asm from last homework assignment compiled into machine code.  

labels do not work completely as intended.

written in python & build.sh is empty.
